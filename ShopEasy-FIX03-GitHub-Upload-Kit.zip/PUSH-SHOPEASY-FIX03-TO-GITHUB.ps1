# ShopEasy FIX03 - complete GitHub import (Windows PowerShell 5.1+)
# Usage: place this script beside ShopEasy-2.8.95-FIX03-FULL-PROJECT.zip, then run it.
$ErrorActionPreference = 'Stop'
$repo = 'https://github.com/rojhawar24-spec/shopeasy-fix03.git'
$archive = Join-Path $PSScriptRoot 'ShopEasy-2.8.95-FIX03-FULL-PROJECT.zip'
$work = Join-Path $PSScriptRoot 'shopeasy-fix03-github-upload'
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git is not installed. Install Git for Windows first.' }
if (-not (Test-Path -LiteralPath $archive)) { throw "Missing archive: $archive" }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead($archive)
try {
  $entries = @($zip.Entries | Where-Object { $_.Name -ne '' })
  if ($entries.Count -ne 1195) { throw "Expected 1195 source files; found $($entries.Count). Wrong archive?" }
  $bad = @($entries | Where-Object { $_.FullName -match '(^|/|\\)\.git(/|\\|$)' -or $_.FullName -match '^(/|\\)' -or $_.FullName -match '(^|/|\\)\.\.(/|\\|$)' })
  if ($bad.Count) { throw 'Archive contains an unsafe path; stopping.' }
} finally { $zip.Dispose() }
if (Test-Path -LiteralPath $work) { throw "Work folder already exists: $work. Rename or remove it yourself after checking its contents." }
& git clone --branch main $repo $work
if ($LASTEXITCODE -ne 0) { throw 'Git clone failed. Check access and authentication.' }
$staging = Join-Path $PSScriptRoot 'shopeasy-fix03-extracted'
if (Test-Path -LiteralPath $staging) { throw "Extraction folder already exists: $staging" }
New-Item -ItemType Directory -Path $staging | Out-Null
Expand-Archive -LiteralPath $archive -DestinationPath $staging
$sourceFiles = @(Get-ChildItem -LiteralPath $staging -Recurse -File -Force)
if ($sourceFiles.Count -ne 1195) { throw 'Source extraction count mismatch.' }
# Remove only tracked working-tree files from newly cloned workspace, preserving .git.
Get-ChildItem -LiteralPath $work -Force | Where-Object { $_.Name -ne '.git' } | Remove-Item -Recurse -Force
Get-ChildItem -LiteralPath $staging -Force | Copy-Item -Destination $work -Recurse -Force
Push-Location $work
try {
  & git add -A
  if ($LASTEXITCODE -ne 0) { throw 'git add failed' }
  $staged = @(& git diff --cached --name-only)
  if ($staged.Count -eq 0) { Write-Host 'No changes to commit.'; exit 0 }
  & git diff --cached --check
  if ($LASTEXITCODE -ne 0) { throw 'Whitespace validation failed; inspect staged changes.' }
  & git commit -m 'Import verified ShopEasy 2.8.95 FIX03 full project (1195 files)'
  if ($LASTEXITCODE -ne 0) { throw 'Commit failed; configure git user.name and user.email if necessary.' }
  & git push origin main
  if ($LASTEXITCODE -ne 0) { throw 'Push failed. Local commit is retained in the work folder; fix authentication then run git push origin main there.' }
  Write-Host 'SUCCESS: ShopEasy FIX03 published to GitHub main.'
  & git status --short
  & git log -1 --oneline
} finally { Pop-Location }
